package Assingment;

import java.util.Random;

public class RaceObstacles{
	int obstacle_position;	
//Constructors
	public RaceObstacles() {	
	}

//Methods	
	public int Scatter() {
		Random randnum = new Random();
		obstacle_position = 2 + randnum.nextInt(98);
		return obstacle_position;
	}
	
	public int getPosition(){
		return obstacle_position;
	}
	
}
