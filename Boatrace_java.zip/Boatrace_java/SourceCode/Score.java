package Assingment;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Formatter;
import java.util.Scanner;

public class Score {
	public int playerscore;
//Constructor
	public Score() {
		
	}

//Setter-Getters
	public void setPlayerscore(int score) {
	playerscore = score;
	}
	
	public int getPlayerscore() {
		return playerscore;
	}
	
//Methods
	public void saveScore(String name, int score) {
		try {
			FileWriter writer = new FileWriter("TopScore.txt",true);
			PrintWriter pw = new PrintWriter(writer);
			pw.printf("Name:%s,Score:%d",name,score);
			pw.println("");
			pw.close();	
		} 
		catch (FileNotFoundException fe) {
			// TODO Auto-generated catch block
			System.out.println("File Not Found");
			System.exit(1);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
public void showLeaderboard() {
		Scanner input;
		int score;
		String name;
		try {
			input = new Scanner(new File("TopScore.txt"));
				while(input.hasNext()) {
					name=input.next();
					System.out.printf("%s",name);
					System.out.println("");
				}
				if (input!=null) {
					input.close();
				}
			}	
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File Not Found");
			System.exit(1);
		}
	}

public void IncreaseScore() {
	playerscore++;
}
	}

