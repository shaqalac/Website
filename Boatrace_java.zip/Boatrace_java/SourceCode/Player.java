package Assingment;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;

public class Player {
		private String name;
		private int dicenum; 
		
//Constructor		
public Player() {
			}
		
public Player(String a){
	setName(a);
	}

//Setter-Getter
public String getName() {
		return name;
	}


public void setName(String name) {
	this.name = name;
	}
		

public int getDice(){
	return dicenum;
}

//To string
public String toString() {
		return String.format("Name:%s",name);
		}

//Functions
public int rollDice() {
	Random randnum = new Random();
	 dicenum= 1+ randnum.nextInt(6);
	 return dicenum;
	 }



}

