package Assingment;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class Game {	
	static Scanner input= new Scanner(System.in);
	static boolean x=true;
	static boolean y=true;
	static boolean z=true;
	final static int start=1;
	
	public Game(){
		
	}
	
	//Methods
public void startGame(){
	System.out.println("Welcome to the Boat Race");
    System.out.println("Here is how the game works");
    System.out.println("1)Each Player has 1 boat. The player's boat that reaches the finish line first (100th Position) wins the game.");
    System.out.println("2)The path has 5 traps and 5 currents which are scattered that move your boat backwards and forwards respectively.");
    System.out.println("3)Each player gets to roll the dice once at each turn");
    System.out.println("4)If a Player Rolls 6 he/she gets to roll again"); 
    System.out.println("Good Luck!!!");
    System.out.print("\n");
    
    //Creating Player Objects
	  Player Player1 = new Player();
	  Player Player2 = new Player();
    //Creating Score Objects
    Score Score1 = new Score();
    Score Score2 = new Score();
    //Displaying Leaderboard
    System.out.println("Leaderboard");
  	Score1.showLeaderboard();
  	System.out.println("");
    
  	//Taking names from user
    System.out.print("Player1 name:");
    Player1.setName(input.nextLine());
    System.out.print("Player2 name:");
    Player2.setName(input.nextLine()); 
    System.out.print("\n");
 
   
    //Creating Boat Objects
    Boat Boat1 = new Boat(1);
    Boat Boat2 = new Boat(1);
    
    //Creating Traps and Currents
    Trap Trap1 = new Trap();
	Trap Trap2 = new Trap();
	Trap Trap3 = new Trap();
    Trap Trap4 = new Trap();
	Trap Trap5 = new Trap();
	Current Current1 = new Current();
	Current Current2 = new Current();
	Current Current3 = new Current();
	Current Current4 = new Current();
	Current Current5 = new Current();
	
	//Placing Currents and Traps on the track
    ArrayList<RaceObstacles> RaceObstacles = new ArrayList<RaceObstacles>();
    RaceObstacles.add(Current1);
    RaceObstacles.add(Current2);
    RaceObstacles.add(Current3);
    RaceObstacles.add(Current4);
    RaceObstacles.add(Current5);
    RaceObstacles.add(Trap1);
    RaceObstacles.add(Trap2);
    RaceObstacles.add(Trap3);
    RaceObstacles.add(Trap4);
    RaceObstacles.add(Trap5);
    for (RaceObstacles rc: RaceObstacles ) {
     rc.Scatter();
    }
   
    //Displaying Trap Position
    System.out.println("Generating Traps..........");
    System.out.println("Trap 1 position:"+Trap1.getPosition());
    System.out.println("Trap 2 position:"+Trap2.getPosition());
    System.out.println("Trap 3 position:"+Trap3.getPosition());
    System.out.println("Trap 4 position:"+Trap4.getPosition());
    System.out.println("Trap 5 position:"+Trap5.getPosition());
    System.out.print("\n");
    
    //Displaying Current Position
    System.out.println("Generating Currents..........");
    System.out.println("Current 1 position:"+Current1.getPosition());
    System.out.println("Current 2 position:"+Current2.getPosition());
    System.out.println("Current 3 position:"+Current3.getPosition());
    System.out.println("Current 4 position:"+Current4.getPosition());
    System.out.println("Current 5 position:"+Current5.getPosition());
    System.out.print("\n");
    
    //Player1 Turn
    while (y==true) {
    	while (x==true) {
    //Turn Skipped When Player 2 rolls Six
    		 if(Player2.getDice()==6) {
 				break;
 			}
    //Player 1 Turn
    		System.out.println("Player 1 turn");
		    System.out.print("Type Y to Roll Dice (Player 1)"); 
		    	if (input.nextLine().equals("Y")) {
				    System.out.print("Player 1 Rolled:");
				    System.out.print(Player1.rollDice() +"\n");
				    Score1.IncreaseScore();
    //Game
		    Boat1.moveForwards(Player1.getDice());
	//If Boat Position crosses Border
		    Boat1.BorderCheck(Boat1, Player1);
	//Displays Position Of Boat
		    System.out.print("Your Boat is in the "+Boat1.getPosition()+"th Position");
		    System.out.println("\n");
		    
	//When Player1 steps on Traps
			   for(RaceObstacles rc: RaceObstacles ) {
				     if(rc instanceof Trap) {
				    	 if(Boat1.getPosition()==rc.getPosition()) {
				    		System.out.print("Your Boat has Fallen on a Trap and has to move "+((Trap)rc).getTrapvalue()+" positions backwards. ");
						    Boat1.moveBackwards(((Trap)rc).getTrapvalue());
						    System.out.print("Your Boat is in the "+Boat1.getPosition()+"th Position");
							System.out.println("\n");
				    	 }
				     }
				    }
		      
	  //When Player1 steps on Currents
			   for(RaceObstacles rc: RaceObstacles ) {
				     if(rc instanceof Current) {
				    	 if(Boat1.getPosition()==rc.getPosition()) {
				    		System.out.print("Your Boat has Fallen on a Current and has to move "+((Current)rc).getCurrentvalue()+" positions Forwards. ");
						    Boat1.moveForwards(((Current)rc).getCurrentvalue());
						    System.out.print("Your Boat is in the "+Boat1.getPosition()+"th Position");
							System.out.println("\n");
				    	 }
				      }
				    }
		  //If Boat crosses Border
			   Boat1.BorderCheck(Boat1, Player1);
		    
		    //Additional Turn If Player Rolls Six
		    if(Player1.getDice()==6) {
				System.out.print("You Rolled Six!! Roll Again");
				System.out.println("\n");
				break;
		    }
		    
    //End of the Game for Player1
		    if (Boat1.getPosition()==100) {
		    	 System.out.println("Congrats Player 1 won");
		    	 System.out.println("You took "+ Score1.getPlayerscore()+" turns");
		    	 System.out.println("Thank you For Playing");
		    	 y=false;
		    	 x=false;
		    	 z=false;
		    	 Score1.saveScore(Player1.getName(),Score1.getPlayerscore());
		    	 }
		    break;}
	//If Player1 Does Not Input "Y"
		    	else {
		    		System.out.print("Wrong Input,Try Again");
		    		System.out.println("");
		    		}
		    	}
    	 
   // Player 2 Turn
	    while (z==true) {
	    //Turn Skipped When Player 1 rolls Six
   		 if(Player1.getDice()==6) {
				break;
			}
   		 //Player 2 Turn
    	 System.out.println("Player 2 turn");
		    System.out.print("Type Y to Roll Dice (Player 2)");
		    
		    if (input.nextLine().equals("Y")) {
			    System.out.print("Player 2 Rolled:");
			    System.out.print(Player2.rollDice() +"\n");
			    Score2.IncreaseScore();
	    //Game
			  	  
			    Boat2.moveForwards(Player2.getDice());
			    if (Boat2.getPosition()>100) {
					   Boat2.moveBackwards(Player2.getDice());
					   System.out.println("OOPS, You Have crossed the boundary,You need to roll "+(100-Boat2.getPosition()));
				   }
			    System.out.print("Your Boat is in the "+Boat2.getPosition()+"th Position");
			    System.out.println("\n");
			  //If the Boat Crosses the Boundary
				   Boat2.BorderCheck(Boat2, Player2);
			    	
			  //When Player2 steps on Traps
				   for(RaceObstacles rc: RaceObstacles ) {
					     if(rc instanceof Trap) {
					    	 if(Boat2.getPosition()==rc.getPosition()) {
					    		System.out.print("Your Boat has Fallen on a Trap and has to move "+((Trap)rc).getTrapvalue()+" positions backwards. ");
							    Boat2.moveBackwards(((Trap)rc).getTrapvalue());
							    System.out.print("Your Boat is in the "+Boat2.getPosition()+"th Position");
								System.out.println("\n");
					    	 }
					     }
					    }
			      
		  //When Player2 steps on Currents
				   for(RaceObstacles rc: RaceObstacles ) {
					     if(rc instanceof Current) {
					    	 if(Boat2.getPosition()==rc.getPosition()) {
					    		System.out.print("Your Boat has Fallen on a Current and has to move "+((Current)rc).getCurrentvalue()+" positions Forwards. ");
							    Boat2.moveForwards(((Current)rc).getCurrentvalue());
							    System.out.print("Your Boat is in the "+Boat2.getPosition()+"th Position");
								System.out.println("\n");
					    	 }
					     }
					    }
		    
		  //When Boat Position crosses Border
			   Boat2.BorderCheck(Boat2, Player2);
		    
		    
		 //Additional Turn If Player Rolls Six
		    if(Player2.getDice()==6) {
				System.out.print("You Rolled Six!! Roll Again");
				System.out.println("\n");
				break;
			}
		    
		    //End of the Game for Player2
		    if (Boat2.getPosition()==100) {
		    	 System.out.println("Congrats Player 2 won");
		    	 System.out.println("You took "+ Score2.getPlayerscore()+" turns");
		    	 System.out.println("Thank you For Playing");
		    	 Score2.saveScore(Player2.getName(),Score2.getPlayerscore());
		    	 y=false;
		    	 x=false;
		    	 z=false;
		    	 break;}
		    break;}
		  //If Player2 Does Not Input "Y"
		    else {
	    		System.out.print("Wrong Input,Try Again");
	    		System.out.println("");
	    		}
	         }
	    }
		       
    }	


}
    








	

