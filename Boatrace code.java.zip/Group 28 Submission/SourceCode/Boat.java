package Assingment;

//Constructors
public class Boat {
	private int position;
	
	
public Boat(int startposition) {
	position= startposition;
}

//Setter-Getter
public int getPosition() {
	return position;	
}

//Functions
public void moveForwards(int n) {
	position+=n;
}

public void moveBackwards(int a) {
	position-=a;
}

public void BorderCheck(Boat BoatNo, Player PlayerNo) {
	  if (BoatNo.getPosition()>100) {
		   BoatNo.moveBackwards(PlayerNo.getDice());
		   System.out.println("OOPS, You Have crossed the boundary,You need to roll "+(100-BoatNo.getPosition()));
	   }
}
}
