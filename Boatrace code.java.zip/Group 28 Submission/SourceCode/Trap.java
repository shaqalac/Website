package Assingment;

import java.util.Random;

public class Trap extends RaceObstacles{
	
private int trap_value;

public Trap() {
	Random randnum = new Random();
    trap_value = 1+randnum.nextInt(6);

}

//Function
public int getTrapvalue() {
	return trap_value;
}

	}
	



