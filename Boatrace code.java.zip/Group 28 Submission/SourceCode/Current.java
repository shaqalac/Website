package Assingment;

import java.util.Random;

public class Current extends RaceObstacles {
	private int current_value;
//Constructors	
	public Current() {
	Random randnum = new Random();
    current_value = 1+randnum.nextInt(6);}
	
//Function
public int getCurrentvalue() {
		return current_value;
	}


}
